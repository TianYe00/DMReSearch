#' The toy data extracted from the Hasen (2011) WGBS data set
#' 
#' This data set cansists of 1000 CpGs and 6 sample in two biological groups.
#' 
#' @format This data set is "MethylDataSet" class data which is well prepared for the following analysis.
#' @references
#' Hansen, K. D. and Timp, W., Bravo, H. C., Sabunciyan, S., Langmead, B., McDonald, O. G., Wen, B., Wu, H., Liu, Y.,
#'  Diep, D., Briem, E., Zhang, K., Irizarry, R. A. and Feinberg, A, P. (2011). Increased methylation variation
#'   in epigenetic domains across cancer types. \emph{Nature Genetics}, 43, 768-775.
"data.toy"

#' Filter and generate the "MethylDataSet" class data.
#' 
#' This function filter CpGs based on their total read counts and prepare the "MethylDataSet" class
#' data for the following analysis. This function can only analyze one chromosome at one time. In order
#' to filter out the CpGs with too low coverage, we only keep the CpGs whose total count is larger than
#' or equal to the \code{minCount} in at least \code{filter} times the number of samples in each biological
#' group.
#' 
#'  @param sampleDesign The information of samples. This argument is the bological group labels for samples.
#'  @param cpgPos The information of CpGs. It is the list which contain the chromosome label, the strand 
#'  direction and the position in the strand.
#'  @param totalCount The \eqn{P \times N} total count matrix with \eqn{N} samples and \eqn{P} CpGs.
#'  @param methylCount The \eqn{P \times N} methylated count matrix with \eqn{N} samples and \eqn{P} CpGs.
#'  @param filter The ratio for filter. 
#'  @param minCount The minimal total count threshold for filter.
#'  @return
#'  \item{y} {The "MethylDataSet" class data set.}
#'  @examples
#'  # sampleDesign = c(rep("cancer", 3), rep("control", 3))
#'  # names(sampleDesign) = c("C1", "C2", "C3", "N1", "N2", "N3")
#'  # position = 1:1000
#'  # cpgPos = list(chr = rep("chr22", 1000), strand = rep("*", 1000), position = position)
#'  # totalCount = matrix(rpos(6000, lambda = 10), ncol = 6)
#'  # methylCount = rbinom(6000, size = totalCount, prob = 0.5)
#'  # toy.data = MethylDataSet(sampleDesign, cpgPos, totalCount, methylCount)
#'  @export
MethylDataSet <- function(sampleDesign, cpgPos, totalCount, methylCount, filter = 2/3, minCount = 2) {
  n = ncol(totalCount)
  cpgPos = data.frame(cpgPos)
  ind1 = which(sampleDesign == "control")
  ind2 = (1:n)[-ind1]
  if (length(unique(cpgPos$strand)) == 2) {
    ind.p = which(cpgPos$strand == "+")
    ind.n = (1:length(cpgPos$strand))[-ind.p]
    pos.p = cpgPos$position[ind.p]
    pos.n = cpgPos$position[ind.n] - 1
    pos.i = intersect(pos.p, pos.n)
    inter.p = ind.p[which(pos.p == pos.i)]
    inter.n = ind.n[which(pos.n == pos.i)]
    ind.new = c(ind.p, ind.n[-inter.n])
    cpgPos$chr = cpgPos$chr[ind.new]
    cpgPos$strand = rep("*", length(ind.new))
    cpgPos$position = c(pos.p, pos.n[-inter.n])
    totalCount[inter.p, ] = totalCount[inter.p, ] + totalCount[inter.n, ]
    totalCount = totalCount[-inter.n, ]
    methylCount[inter.p, ] = methylCount[inter.p, ] + methylCount[inter.n, ]
    methylCount = methylCount[-inter.n, ]
    ind.order = order(cpgPos$position)
    cpgPos = cpgPos[ind.order, ]
    totalCount = totalCount[ind.order, ]
    methylCount = methylCount[ind.order, ]
  }
  totalCount.a = (totalCount >= minCount)
  cpg.keep1 = which(rowSums(totalCount.a[, ind1]) >= ceiling(filter * length(ind1)))
  cpg.keep2 = which(rowSums(totalCount.a[, ind2]) >= ceiling(filter * length(ind2)))
  cpg.keep = intersect(cpg.keep1, cpg.keep2)
  totalCount = totalCount[cpg.keep, ]
  methylCount = methylCount[cpg.keep, ]
  methylLevel = methylCount/totalCount
  methylLevel[is.na(methylLevel)] = 0
  cpgPos = cpgPos[cpg.keep, ]
  rownames(methylLevel) = cpgPos$position
  colnames(methylLevel) = names(sampleDesign)
  if (length(rownames(totalCount)) == 0 | length(rownames(methylCount)) == 0) {
    rownames(totalCount) = cpgPos$position
    rownames(methylCount) = cpgPos$position
  }
  if (length(rownames(totalCount)) == 0 | length(rownames(methylCount)) == 0) {
    colnames(totalCount) = names(sampleDesign)
    colnames(methylCount) = names(sampleDesign)
  }
  y = list(sampleDesign = sampleDesign, 
           cpgPos = cpgPos,
           totalCount = totalCount,
           methylCount = methylCount,
           methylLevel = methylLevel)
  class(y) = "MethylDataSet"
  return(y)
}

#' Internal function for DMReSearch package.
ComputeDensity <- function(cpgPosCtr, dc){
  PosC = cpgPosCtr$position
  
  empPos = rep(NA, dc)
  newPosC = c(empPos, PosC, empPos)
  
  countC <- function(k)
  {
    pos.k = newPosC[(k-dc):(k+dc)]
    pna = which(is.na(pos.k))
    if(length(pna) > 0) pos.k = pos.k[-pna]
    pk = newPosC[k]
    check = pos.k[pos.k <= pk + dc & pos.k >= pk-dc]
    
    d = length(check)
    return(d)
  }
  
  posId = (dc + 1):(dc + length(PosC))
  posId = as.matrix(posId)
  
  density = apply(posId, 1, countC)
  cpgDensity = list(chr = cpgPosCtr$chr, strand = cpgPosCtr$strand, position = cpgPosCtr$position, density = density)
  return(cpgDensity)
  
}

#' Internal function for DMReSearch package.
ComputeDelta <- function(cpgDensity){
  density = cpgDensity$density
  posC = cpgDensity$position
  ind = order(density)
  density = density[ind]
  sort.posC = posC[ind]
  l = length(posC)
  dl = density[l]
  Compare <- function(i)
  {
    di = density[i]
    if(di == dl)
    {
      d = max(sort.posC[i] - posC[1], posC[l]-sort.posC[i])
      return(d)
    }
    else
    {	
      if(di < 3) return(1)
      else{
        pi = sort.posC[i]
        lgd = density[(i+1):l]
        hDPos = sort.posC[(i+1):l]
        hDPos = hDPos[which(lgd > di)]
        dist = abs(hDPos - pi)
        return(min(dist))
      }			
    }
    
  }
  delta = rep(0,l)
  for(i in 1:l){
    delta[i] = Compare(i)
  }
  ind = order(sort.posC)
  cpgDensity$delta = delta[ind]
  return(cpgDensity)	
}

#' Internal function for DMReSearch package.
GetMeanLevels <- function(methylCountCtr, totalCountCtr){
  methylLevelCtr = methylCountCtr/totalCountCtr
  
  methylLevelCtr[is.na(methylLevelCtr)] = 0
  sumMLevel = rowSums(methylLevelCtr)
  countMLevel = totalCountCtr
  countMLevel[totalCountCtr > 0] = 1
  countML = rowSums(countMLevel)
  
  meanMLevel = sumMLevel / countML
  
  return(meanMLevel)
}

#' Internal function for DMReSearch package.
GetSDLevels <- function(cpgPosCtr, meanMLevel, nc){
  PosC = cpgPosCtr$position	
  l = length(PosC)
  sdneighborC <- function(k)
  {
    if(k <= nc)
    {
      lev.k = meanMLevel[1:(k+nc)]
    }
    else
    {
      if(k > l - nc)
      {
        lev.k = meanMLevel[(k-nc):l]
      }
      else
      {
        lev.k = meanMLevel[(k-nc):(k+nc)]
      }
    }
    
    return(sd(lev.k))
  }
  
  idc = 1:l
  sdLevels = apply(as.matrix(idc), 1, sdneighborC)
  sdLevels[is.na(sdLevels)] = 0
  return(sdLevels)
}

#' Internal function for DMReSearch package.
ClusterCenter <- function(methylDataSetCtr, dc, thCenter){
  cpgPosCtr = methylDataSetCtr$cpgPos
  totalCountCtr = methylDataSetCtr$totalCountCtr
  methylCountCtr = methylDataSetCtr$methylCountCtr
  totalCountCan = methylDataSetCtr$totalCountCan
  methylCountCan = methylDataSetCtr$methylCountCan
  
  densityCtr = ComputeDensity(cpgPosCtr, dc)
  qtD = quantile(densityCtr$density)
  DensDeltCtr = ComputeDelta(densityCtr)
  qtDl = quantile(DensDeltCtr$delta)
  meanLevelCtr = GetMeanLevels(methylCountCtr, totalCountCtr)
  meanLevelCan = GetMeanLevels(methylCountCan, totalCountCan)
  ncpg = 3 * round(mean(DensDeltCtr$density))
  meanLevelDiff = meanLevelCan - meanLevelCtr
  sdLevelCtr = GetSDLevels(cpgPosCtr, meanLevelDiff, ncpg)
  qtSd = quantile(sdLevelCtr)
  indmx = which(DensDeltCtr$delta == max(DensDeltCtr$delta))	
  GammaCtr = DensDeltCtr$density[-indmx] * DensDeltCtr$delta[-indmx]/exp(10*sdLevelCtr[-indmx])	
  posCtmp = cpgPosCtr$position[-indmx]  
  ind.order = order(GammaCtr)
  density.order = DensDeltCtr$density[-indmx]
  density.order = density.order[ind.order]
  posCtmp.order = posCtmp[ind.order]
  threshold = round(thCenter * length(GammaCtr))  
  lg = length(GammaCtr)
  posCtmp.center = posCtmp.order[threshold:lg]
  density.center = density.order[threshold:lg]
  clusterCenter = posCtmp.center[density.center>2]  
  GammaCenter = GammaCtr[ind.order]
  GammaCenter = GammaCenter[threshold:lg]
  GammaCenter = GammaCenter[density.center>2]  
  l = length(clusterCenter)
  dens.max = DensDeltCtr$density[indmx]
  if(dens.max[1] > 2){
    clusterCenter = c(clusterCenter,cpgPosCtr$position[indmx])		
    ind = order(clusterCenter)
    clusterCenter = clusterCenter[ind]
    GammaCenter = GammaCenter[ind]
  }
  
  nCenter = length(clusterCenter) 
  if(nCenter > 1){
    pc1 = clusterCenter[1]
    neighbor = rep(0,nCenter)
    ngb = 0
    for(i in 2:nCenter){
      pci = clusterCenter[i]
      if(pci - pc1 <= 300){			
        if(neighbor[i-1]==0){
          ngb = ngb + 1
          neighbor[i-1] = ngb
        }
        neighbor[i] = ngb
      }
      pc1 = pci
    }   
    newCenter = clusterCenter[neighbor == 0]    
    if(length(newCenter) < nCenter){
      neighbor.max = max(neighbor)	  
      for(k in 1:neighbor.max){
        ind.k = which(neighbor == k)
        center.k = clusterCenter[ind.k]
        center.y = center.k[round(length(center.k)/2)]        
        newCenter = c(newCenter, center.y)	          
      }      
      nCenter = length(newCenter)
      clusterCenter = newCenter
    }
  }
  return(clusterCenter)	
}

#' Internal function for DMReSearch package.
DefineBoundary <- function(methylDataSetCtr, clusterCenter, bId, dc, minSize, totalC, posTotalC){
  cpgPosCtr = methylDataSetCtr$cpgPos
  PosC = cpgPosCtr$position
  firstC = min(PosC)
  lastC = max(PosC)
  allC = length(PosC)
  nCluster = length(clusterCenter)
  center.order = order(clusterCenter)
  clusterCenter = clusterCenter[center.order]
  cluster = matrix(nrow = 1, ncol = allC)
  cluster[is.na(cluster)] = 0
  colnames(cluster) = PosC
  MarkCenter <- function(k){
    cluster[1, which(PosC == clusterCenter[k])] <<- k
  }
  v = apply(as.matrix(1:nCluster), 1, MarkCenter)
  x = clusterCenter[1]
  inbd = which(PosC < x & PosC >= firstC)
  if(length(inbd)>0){
    bd = PosC[inbd]
    while(x >= firstC){
      le = max(c(x - dc, firstC))
      lx = which(bd >= le & bd < x)				
      if(length(lx) == 0) break
      cluster[1,inbd[lx]] = 1		
      x = min(bd[lx])
    }
  }
  y = clusterCenter[nCluster]
  inbd = which(PosC > y & PosC <= lastC)
  if(length(inbd)>0){
    bd = PosC[inbd]	
    while(y <= lastC){
      re = min(c(y + dc,lastC))
      ry = which(bd <= re & bd > y)
      if(length(ry)==0) break
      cluster[1,inbd[ry]] = nCluster
      y = max(bd[ry])
    }
  }	  
  for(i in 1 : (nCluster - 1)){
    cx = clusterCenter[i]
    cy = clusterCenter[i + 1]
    ind.xy = which(PosC > cx & PosC < cy)
    v.xy = PosC[ind.xy]
    x = cx
    y = cy
    re = min(c(x + dc, y - 1))
    le = max(c(re + 1, y - dc))
    rx = which(v.xy <= re)
    ly = which(v.xy >= le)    
    while(1){
      lrx = length(rx)
      lly = length(ly)
      if(lrx > 0){
        cluster[1,ind.xy[rx]] = i
        x = max(v.xy[rx])	
        re = min(c(x+dc, le - 1))
      }
      else re = x      
      if(lly > 0){
        cluster[1, ind.xy[ly]] = i + 1
        y = min(v.xy[ly])
        le = max(c(re + 1, y - dc))
      }
      else le = y    
      if(lrx + lly == 0) break
      if(y - x <= 1) break
      
      rx = which(v.xy <= re & v.xy > x)
      ly = which(v.xy >= le & v.xy < y)
    }						
  }  
  freeC = cluster[, cluster == 0]
  nameFreeC = which(cluster[1,] == 0)	  
  freeDataSet = list(sampleDesign = methylDataSetCtr$sampleDesign, 
                     cpgPos = methylDataSetCtr$cpgPos[nameFreeC,], 
                     totalCountCtr = methylDataSetCtr$totalCountCtr[nameFreeC,],
                     methylCountCtr = methylDataSetCtr$methylCountCtr[nameFreeC,],
                     methylLevelCtr = methylDataSetCtr$methylLevelCtr[nameFreeC,],
                     totalCountCan = methylDataSetCtr$totalCountCan[nameFreeC,],
                     methylCountCan = methylDataSetCtr$methylCountCan[nameFreeC,])
  cluster.t = table(cluster[1,])
  
  marker = names(cluster.t)
  marker = as.numeric(marker)  
  nCluster = ifelse(length(freeC) > 0, length(marker) - 1, length(marker))  
  clusterId = vector(mode = "numeric", length = totalC)
  if(nCluster > 0){
    clusterRange = matrix(nrow = nCluster, ncol = 3)		
    nr = 1
    if(length(freeC)>0){
      marker2 = marker[2:length(marker)]
    }else{
      marker2 = marker
    }    
    for(m in marker2){
      cluster.m = which(cluster[1,] == m)
      lm = length(cluster.m)      
      clusterRange[nr,1] = PosC[cluster.m[1]]
      clusterRange[nr,2] = PosC[cluster.m[lm]]
      clusterRange[nr,3] = lm      
      nr = nr+1
    }
    num.row = nCluster
    if(num.row > 1){
      for(m in 2:num.row){
        dl = clusterRange[m,1] - clusterRange[m-1,2]		  
        if(dl <= dc){
          clusterRange[m-1,2] = clusterRange[m,2]
          clusterRange[m-1,3] = clusterRange[m-1,3] + clusterRange[m,3]
          clusterRange[m,] = c(0,0,0)
        }
      }
      size.cluster = clusterRange[,3]
      ind.yes = which(size.cluster >= minSize)         
      clusterRange = clusterRange[ind.yes,]      
      nCluster = length(ind.yes)
    }
    else{
      if(clusterRange[,3] < minSize){
        clusterRange = matrix()
        methylCluster = list(methylDataSet = methylDataSetCtr, clusterRange = clusterRange, clusterId = clusterId, freeDataSet = freeDataSet)      
        return(methylCluster)
      } 
    }    
    tag = bId + 1 : nCluster
    if(is.vector(clusterRange)){
      clusterRange = matrix(clusterRange, nrow=1)
    }
    rownames(clusterRange) = tag
    MarkCluster <- function(r){
      clusterId[posTotalC <= clusterRange[r,2] & posTotalC >= clusterRange[r,1]] <<- tag[r]
    }
    t = apply(as.matrix(1:nCluster), 1, MarkCluster)    
  }
  else{
    clusterRange = matrix()
  }
  methylCluster = list(methylDataSet = methylDataSetCtr, clusterRange = clusterRange, clusterId = clusterId, freeDataSet = freeDataSet)
  
  return(methylCluster)
}

#' Internal function for DMReSearch package.
UpdateDataSet <- function(clusterMethylC, methylCluster){  
  if(length(clusterMethylC) == 0){
    clusterMethylC$methylDataSet = methylCluster$methylDataSet
    clusterMethylC$clusterId = methylCluster$clusterId
    clusterMethylC$clusterRange = methylCluster$clusterRange
    clusterMethylC$freeDataSet = methylCluster$freeDataSet
  }
  else{
    clusterIdOrg = clusterMethylC$clusterId
    clusterIdNew = methylCluster$clusterId
    clusterMethylC$clusterId = clusterIdOrg + clusterIdNew
    clusterMethylC$methylDataSet = methylCluster$methylDataSet		
    clusterMethylC$clusterRange = rbind(clusterMethylC$clusterRange, methylCluster$clusterRange)	    
    clusterMethylC$freeDataSet = methylCluster$freeDataSet
  }  
  return(clusterMethylC)
}

#' Pre-cluster the CpGs by using 3D rank method.
#' 
#' Pre-cluster the CpGs by using 3D rank method.
#' @param methylDataSet The well prepared data from MethylDataSet.
#' @param dc The maximal distance between two adjacent CpGs in one cluster.
#' @param minSize The minimal number of CpGs in one cluster.
#' @param thCenter The ratio to choose centers in the 3D rank for each iteration. In each iteration we choose
#' top \code{thCenter} CpGs as centers.
#' @return
#' \item{methylDataSet}{The updated "methylDataSet" class data.}
#' \item{clusterRange}{The information of pre-clustered ragions. It includes the start and end
#'  positions of all clusters and the number of CpGs in each cluster.}
#' @examples
#' # data("data.toy")
#' # cluster.toy = ClusterMethylC(data.toy)
#' @export
ClusterMethylC <- function(methylDataSet, dc = 300, minSize = 3, thCenter = 0.02)
{	
  sampleDesign = as.matrix(methylDataSet$sampleDesign)
  rowCtr = which(sampleDesign=="control")
  methylDataSetCtr = list(sampleDesign = sampleDesign[rowCtr], 
                          cpgPos = methylDataSet$cpgPos,
                          totalCountCtr = methylDataSet$totalCount[,rowCtr],
                          methylCountCtr = methylDataSet$methylCount[,rowCtr],
                          methylLevelCtr = methylDataSet$methylLevel[,rowCtr],
                          methylCountCan = methylDataSet$methylCount[, -rowCtr],
                          totalCountCan = methylDataSet$totalCount[, -rowCtr])
  cpgPosCtr = methylDataSetCtr$cpgPos
  totalC = nrow(cpgPosCtr)
  posTotalC = cpgPosCtr$position 
  freeDataSet = methylDataSetCtr
  bId = 0
  clusterMethylC = list()
  clusterTimes = 0
  thCenter = 1 - thCenter
  while(nrow(freeDataSet$cpgPos) > 0)
  {
    clusterCenter = ClusterCenter(freeDataSet, dc, thCenter)		   
    if(length(clusterCenter) == 0) break    
    methylCluster = DefineBoundary(freeDataSet, clusterCenter, bId, dc, minSize, totalC, posTotalC)
    if(is.na(methylCluster$clusterRange[1,1]) == FALSE){
      clusterMethylC = UpdateDataSet(clusterMethylC, methylCluster)
    }else{
      clusterTimes = clusterTimes + 1
      cat(clusterTimes, ": ", bId, " clusters are identified so far.\n")	
    } 
    clusterTimes = clusterTimes + 1		
    freeDataSet = methylCluster$freeDataSet
    bId = nrow(clusterMethylC$clusterRange)
    cat(clusterTimes, ": ", bId, " clusters are identified so far.\n")		   
  }
  cpgPosCtr$clusterId = clusterMethylC$clusterId
  methylDataSet$cpgPos = cpgPosCtr
  clusterRange = clusterMethylC$clusterRange	
  clusterSize = clusterRange[,2] - clusterRange[,1] + 1
  clusterRange[,3] = clusterSize
  colnames(clusterRange) = c("start","end","size")
  clusterMethylC = list(methylDataSet = methylDataSet, clusterRange = clusterRange)
  return(clusterMethylC)
}

#' The modified local kernel smoothing method.
#' 
#' Smooth the pre-clustered "MethylDataSet" data by using modified local triangular kernel method.
#' @param object The "MethlDataSet" data from \code{ClusterMethylC} function.
#' @param clusterRange The information of pre-clustered ranges from \code{ClusterMethylC} function.
#' @param size The window size for smoothing
#' @return
#' \item{smoothed}{The matrix that contains the smoothed methylation levels.}
#' @examples
#' # data("data.toy")
#' # cluster.toy = ClusterMethylC(data.toy)
#' # smooth.toy = SmoothCluster(cluster.toy$methylDataSet, cluster.toy$clusterRange)
#' @export
SmoothCluster <- function(object, clusterRange, size = 100){
  pos = object$cpgPos$position
  smoothed = object$methylLevel
  j = ncol(object$totalCount)
  for (i in 1:nrow(clusterRange)) {
    ind.c = which(object$cpgPos$clusterId == i)
    l = length(ind.c)
    weight = log(1 + object$totalCount[ind.c, ])
    if (clusterRange[i, 3] <= (size + 1) ) {
      dist = matrix(rep(pos[ind.c], l), nrow = l)
      dist = t(abs(t(dist) - pos[ind.c]))
      ker = 1 - dist/size
      for(b in 1:j) {
        weight.c = matrix(rep(weight[, b], l), nrow = l)
        diag(weight.c) = max(weight)
        kw = ker * weight.c
        smoothed[ind.c, b] = colSums(kw * smoothed[ind.c, b])/colSums(kw)
      }
      next
    }
    for (a in 1:l) {
      d = pos[ind.c[a]] - clusterRange[i, 1]
      if (d <= size) {			
        ind.r1 = which(pos[ind.c[(a+1):l]] <= (pos[ind.c[a]] + size))
        ind.r = ind.c[(a+1):l][ind.r1]
        ind = c(ind.c[1:a], ind.r)
        ind.w = c(1:a, ((a+1):l)[ind.r1])
        if(length(ind) ==1) 
          next
        weight.max = apply(weight[ind.w, ], 2, max)
        weight.c = weight[ind.w, ]
        weight.c[a, ] = weight.max
        ker = 1 - abs(pos[ind] - pos[ind.c[a]])/size
        kw = ker * weight.c
        smoothed[ind.c[a], ] = colSums(kw * smoothed[ind, ])/colSums(kw)
      } else {
        if (pos[ind.c[a]] < (clusterRange[i, 2] - size)) {
          ind.w = which((pos[ind.c] >= (pos[ind.c[a]] - size)) &
                          (pos[ind.c] <= (pos[ind.c[a]] + size)))
          ind = ind.c[ind.w]
          if(length(ind) ==1) 
            next
          weight.max = apply(weight[ind.w, ], 2, max)
          weight.c = weight[ind.w, ]
          ind.a = which(pos[ind] == pos[ind.c[a]])
          weight.c[ind.a, ] = weight.max
          ker = 1 - abs(pos[ind] - pos[ind.c[a]])/size
          kw = ker * weight.c
          smoothed[ind.c[a], ] = colSums(kw * smoothed[ind, ])/colSums(kw)
        } else {
          ind.l1 = which(pos[ind.c[1:(a - 1)]] >= (pos[ind.c[a]] - size))
          ind.l = ind.c[1:(a - 1)][ind.l1]
          ind = c(ind.l, ind.c[a:l])
          ind.w = c((1:(a - 1))[ind.l1], a:l)
          if(length(ind) ==1) 
            next
          weight.max = apply(weight[ind.w, ], 2, max)
          weight.c = weight[ind.w, ]
          ind.a = which(pos[ind] == pos[ind.c[a]])
          weight.c[ind.a, ] = weight.max
          ker = 1 - abs(pos[ind] - pos[ind.c[a]])/size
          kw = ker * weight.c
          smoothed[ind.c[a], ] = colSums(kw * smoothed[ind, ])/colSums(kw)
          
        }
      }
      
    }
  }
  smoothed[is.na(smoothed)] = 0
  return(smoothed)
}

#' Internal function for DMReSearch package.
Gof.phi <- function(phi, x, mu, n){
  den = n * mu * (1 - mu) * (1 + (n - 1) * phi)
  den[den == 0]  = Inf
  g = rowSums((x - n * mu)^2/den)
  qs = quantile(g, c(0.1, 0.9))
  ind.qs = (g >= qs[1]) & (g <= qs[2])
  abs(sum(g[ind.qs]) - 0.8 * (nrow(x) - 1) * (ncol(x) - 1))
}

#' Identify and trim the DMRs.
#' 
#' Based on the wald test this function can detect DMCs and accodingly find the DMRs.
#' @param object The "MethlDataSet" data from \code{ClusterMethylC} function.
#' @param smoothed The smoothed methylation levels from \code{SmoothCluster}.
#' @param clusterRange The information of pre-clustered ragions from \code{ClusterMethylC} function.
#' @param sigLevel The statistical significance level for wald test.
#' @param minSize The minimal number of CpGs in one DMR.
#' @param dc The maximal distance between two adjacent CpGs in one DMR.
#' @param thres The minimal ratio of DMC in the DMR.
#' @return
#' \item{methylDataSet}{The updated "methylDataSet" class data.}
#' \item{pvalue}{The p-values and the methylation directions of CpGs. For the independent CpGs
#' which cannot be included in any pre-clusters, the corresponding p-values and directions will
#' be NA.}
#' \item{dmrInfo}{The \code{data.frame} to keep the DMRs' information. For each DMR, It contains
#'the cluster ID, start position, end position, number of CpGs and mean pvalues.}
#' @examples
#' # data("data.toy")
#' # cluster.toy = ClusterMethylC(data.toy)
#' # smooth.toy = SmoothCluster(cluster.toy$methylDataSet, cluster.toy$clusterRange)
#' # DMR.toy = TestDMR(cluster.toy$methylDataSet, smooth.toy, cluster.toy$clusterRange)
#' @export
TestDMR <- function(object, smoothed, clusterRange, sigLevel = 0.1, minSize = 3, dc = 300, thres = 0.8){
  ind2 = which(object$sampleDesign == 'control')
  ind1 = (1:ncol(smoothed))[-ind2]
  p = nrow(smoothed)
  mu.hat = matrix(0, p, 2)
  phi.hat = mu.hat
  var.mu = mu.hat
  pvalue = mu.hat
  n.clus = nrow(clusterRange)
  colnames(pvalue) = c('value', 'sign')
  dmrInfo = data.frame(list(clusterId = 0, start = 0, end = 0, n = 0, direction = "hyper", pvalue.mean = 0), stringsAsFactors = FALSE)
  wald = rep(0, p)
  tal = matrix(object$totalCount == 0, nrow = p)
  ntal1 = rowSums(tal[, ind1])
  ntal2 = rowSums(tal[, ind2])
  ind.ntal1 = which(ntal1 > 0)
  ind.ntal2 = which(ntal2 > 0)
  pseudo.totalCount = object$totalCount
  if (length(ind.ntal1) > 0){
    estCount = rowSums(object$totalCount[ind.ntal1, ind1])/(length(ind1) - ntal1[ind.ntal1])
    for (a in 1:length(ind1)){
      pseudo.totalCount[tal[, ind1[a]], ind1[a]] = estCount[tal[ind.ntal1, ind1[a]]] 
    }
    
  }
  if (length(ind.ntal2) > 0){
    estCount = rowSums(object$totalCount[ind.ntal2, ind2])/(length(ind2) - ntal2[ind.ntal2])
    for (a in 1:length(ind2)){
      pseudo.totalCount[tal[, ind2[a]], ind2[a]] = estCount[tal[ind.ntal2, ind2[a]]] 
    }
    
  }
  pseudo.methylCount = pseudo.totalCount * smoothed
  if (length(ind1) == 1){
    mu.hat[, 1] = smoothed[, ind1]
  }else{
    mu.hat[, 1] = rowSums(pseudo.methylCount[, ind1])/rowSums(pseudo.totalCount[, ind1])
  }
  if (length(ind2) == 1){
    mu.hat[, 2] = smoothed[, ind2]
  }else{
    mu.hat[, 2] = rowSums(pseudo.methylCount[, ind2])/rowSums(pseudo.totalCount[, ind2])
  }
  for (i in 1:n.clus){
    ind.c = which(object$cpgPos$clusterId == i)
    phi.hat[ind.c, 1] = optimize(f=Gof.phi, interval = c(1e-5, 4), tol = 1e-3, x = pseudo.methylCount[ind.c, ind1], 
                                 mu = mu.hat[ind.c, 1], n = pseudo.totalCount[ind.c, ind1])$minimum
    phi.hat[ind.c, 2] = optimize(f=Gof.phi, interval = c(1e-5, 4), tol = 1e-3, x = pseudo.methylCount[ind.c, ind2], 
                                 mu = mu.hat[ind.c, 2], n = pseudo.totalCount[ind.c, ind2])$minimum
  }
  if (length(ind1) == 1){
    var.mu[, 1] =  mu.hat[, 1] * (1 - mu.hat[, 1]) * (1 + (pseudo.totalCount[, ind1] - 1) * phi.hat[, 1])/pseudo.totalCount[, ind1]
  }else{
    var.mu[, 1] =  rowSums(mu.hat[, 1] * (1 - mu.hat[, 1]) * (1 + (pseudo.totalCount[, ind1] - 1) * phi.hat[, 1])
                           *pseudo.totalCount[, ind1])/(rowSums(pseudo.totalCount[,1:3])^2)
  }
  if (length(ind2) == 1){
    var.mu[, 2] =  mu.hat[, 2] * (1 - mu.hat[, 2]) * (1 + (pseudo.totalCount[, ind2] - 1) * phi.hat[, 2])/pseudo.totalCount[, ind2]
  }else{
    var.mu[, 2] =  rowSums(mu.hat[, 2] * (1 - mu.hat[, 2]) * (1 + (pseudo.totalCount[, ind2] - 1) * phi.hat[, 2])
                           *pseudo.totalCount[, ind2])/(rowSums(pseudo.totalCount[,ind2])^2)
  }
  mu.diff = mu.hat[, 1] - mu.hat[, 2]
  ind.diff = which(mu.diff == 0)
  pvalue[, 2] = sign(mu.diff)
  if (length(ind.diff) > 0) {
    wald[ind.diff] = 0
    pvalue[ind.diff, 1] = 1
    wald[-ind.diff] = 4/3 * abs(mu.diff[-ind.diff])/sqrt(var.mu[-ind.diff, 1] + var.mu[-ind.diff, 2])
    pvalue[-ind.diff, 1] = 2 * pnorm(-wald[-ind.diff])
  } else {
    wald = 4/3 * abs(mu.diff)/sqrt(var.mu[, 1] + var.mu[, 2])
    pvalue[, 1] = 2 * pnorm(-wald)
  }
  clustId = 1
  pvalue.sign = pvalue[, 2]
  names(pvalue.sign) = NULL
  id0 = which(object$cpgPos$clusterId == 0)
  pvalue[id0, ] = NA
  dmr.id = vector()
  for (i in 1:n.clus){
    ind.c = which(object$cpgPos$clusterId == i)
    kp = (pvalue[ind.c, 1] <= sigLevel)
    ki = ind.c[kp]
    l.ki = length(ki)
    object$cpgPos$clusterId[ind.c] = 0
    if (l.ki >= minSize){
      sp = pvalue.sign[ki]
      dist = object$cpgPos$position[ki[2:l.ki]] - object$cpgPos$position[ki[1:(l.ki - 1)]]
      dist.p = abs(sp[2:l.ki] - sp[1:(l.ki - 1)]) * 5000
      dist.f = dist + dist.p
      cut = which(dist.f > dc)
      if (length(cut) > 0){
        cut.a = c(0, cut, l.ki)
        clust.range = cut.a[2:length(cut.a)] - cut.a[1:(length(cut.a) - 1)]
        dmr.keep = which(clust.range >= minSize)
        if (length(dmr.keep) > 0){
          for (b in 1:length(dmr.keep)){
            dmr.ind = ki[cut.a[dmr.keep[b]]+1]:ki[cut.a[dmr.keep[b]+1]]
            if ((length(ki[(cut.a[dmr.keep[b]]+1):(cut.a[dmr.keep[b]+1])])/length(dmr.ind)) < thres)
              next
            object$cpgPos$clusterId[dmr.ind] = clustId
            dir = ifelse(pvalue.sign[dmr.ind[1]] == 1, "hyper", "hypo")
            pvalue.mean = mean(pvalue[dmr.ind, 1])
            dmrInfo = rbind(dmrInfo, data.frame(clusterId = clustId, start = object$cpgPos$position[dmr.ind[1]],
                                                end = object$cpgPos$position[dmr.ind[length(dmr.ind)]], n = length(dmr.ind), direction = dir, pvalue.mean = pvalue.mean)) 
            dmr.id = rbind(dmr.id, c(ki[(cut.a[dmr.keep[b]]+1)], ki[(cut.a[dmr.keep[b]+1])]))
            clustId = clustId + 1
          }
        }
      }else{
        object$cpgPos$clusterId[ki[1]:ki[l.ki]] = clustId				
        dir = ifelse(pvalue.sign[ki[1]] == 1, "hyper", "hypo")
        pvalue.mean = mean(pvalue[ki[1]:ki[l.ki], 1])
        dmrInfo = rbind(dmrInfo, data.frame(clusterId = clustId, start = object$cpgPos$position[ki[1]], end = object$cpgPos$position[ki[l.ki]],
                                            n = ki[l.ki] - ki[1] + 1, direction = dir, pvalue.mean = pvalue.mean))
        dmr.id = rbind(dmr.id, c(ki[1], ki[l.ki]))
        clustId = clustId + 1
      }
    } 
  }
  dmrInfo = dmrInfo[-1, ]
  ind.ord = order(dmrInfo$start)
  start.ord = dmrInfo$start[ind.ord]
  end.ord = dmrInfo$end[ind.ord]
  lc = length(ind.ord)
  if(lc > 1) {
    clust.dist = start.ord[2:lc] - end.ord[1:(lc - 1)]
    mer = which(clust.dist <= dc)
    lm = length(mer)
    if (lm > 0){
      delet = c()
      mer.ind1 = ind.ord[mer]
      mer.ind2 = ind.ord[mer+1]
      for(a in 1:lm) {
        if (dmrInfo$direction[mer.ind1[a]] == dmrInfo$direction[mer.ind2[a]]){
          id1 = dmrInfo$clusterId[mer.ind1[a]]
          id2 = dmrInfo$clusterId[mer.ind2[a]]
          object$cpgPos$clusterId[dmr.id[id1, 2]:dmr.id[id2, 2]] = id1
          dmrInfo$clusterId[mer.ind2[a]] = id1
          dmrInfo$start[mer.ind2[a]] = dmrInfo$start[mer.ind1[a]]
          dmrInfo$pvalue.mean[mer.ind2[a]] = mean(pvalue[dmr.id[id1, 1]:dmr.id[id2, 2]])
          dmrInfo$n[mer.ind2[a]] = dmr.id[id2, 2] - dmr.id[id1, 1] + 1
          delet = c(delet, mer.ind1[a])
        }
      }
      if(length(delet) > 0){
        dmrInfo = dmrInfo[-delet, ]	
      }
    }
  }
  return(list(methylDataSet = object, pvalue = pvalue, dmrInfo = dmrInfo))
}

